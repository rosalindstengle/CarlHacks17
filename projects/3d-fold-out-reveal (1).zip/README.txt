A Pen created at CodePen.io. You can find this one at http://codepen.io/candroo/pen/wKEwRL.

 Click to reveal more info.
Info folds out beneath the card, while the rest of the grid recedes.