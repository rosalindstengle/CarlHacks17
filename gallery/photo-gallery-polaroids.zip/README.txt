A Pen created at CodePen.io. You can find this one at http://codepen.io/n33kos/pen/NGzaqZ.

 An animated polaroid image splay for photo gallery index pages.